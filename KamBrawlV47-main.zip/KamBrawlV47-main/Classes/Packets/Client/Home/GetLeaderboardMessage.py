from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler


class GetLeaderboardMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["IsLocal"] = self.readVInt()
        fields["Type"] = self.readVInt()
        print(fields["Type"])
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        if fields["Type"] == 1 or fields["Type"] == 0:
            fields["Socket"] = calling_instance.client
            Messaging.sendMessage(24403, fields, cryptoInit, calling_instance.player)
        else:
            #fields["mess"] = "эта функция еще не реализована!"
            fields["Socket"] = calling_instance.client
            Messaging.sendMessage(24104, fields, cryptoInit)
            
    def getMessageType(self):
        return 14403

    def getMessageVersion(self):
        return self.messageVersion