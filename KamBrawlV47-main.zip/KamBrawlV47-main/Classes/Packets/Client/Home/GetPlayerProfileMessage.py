from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage


class GetPlayerProfileMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        # fields["PlayerHighID"] = self.readInt()
        # fields["PlayerLowID"] = self.readInt()
        #fields["PlayerProfileID"] = self.readLong()
        fields["BattleInfoBoolean"] = self.readBoolean()
        fields["unk11"] = self.readVInt()
        fields["PlayerHighID"] = self.readInt()
        fields["PlayerLowID"] = self.readInt()
        super().decode(fields)


        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(24113, fields, cryptoInit, calling_instance.player)

    def getMessageType(self):
        return 15081

    def getMessageVersion(self):
        return self.messageVersion