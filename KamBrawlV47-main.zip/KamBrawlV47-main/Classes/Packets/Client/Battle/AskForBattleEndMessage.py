from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler

class AskForBattleEndMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["Unk1"] = self.readVInt()
        fields["Result"] = self.readVInt()
        fields["Rank"] = self.readVInt()
        fields["MapID"] = self.readDataReference()
        fields["HeroesCount"] = self.readVInt()
        fields["Heroes"] = []
        for i in range(fields["HeroesCount"]): fields["Heroes"].append({"Brawler": {"ID": self.readDataReference(), "SkinID": self.readDataReference()}, "Team": self.readVInt(), "IsPlayer": self.readBoolean(), "PlayerName": self.readString()})
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        
        db_instance = DatabaseHandler()
        playerData = db_instance.getPlayer(calling_instance.player.ID)
        
        if playerData["Trophies"] == 0:
        	#3vs3 rewards start
        	if fields["Unk1"] == 0:
        		playerData["Trophies"] += 8
        		if playerData["BrawlPassTokens"] == 34500:
        			playerData["BonusRewardsTokens"] += 50
        		else:
        			playerData["BrawlPassTokens"] += 50
        		playerData["MasteryPoints"][str(playerData["SelectedBrawlers"][0])] += 300
        		playerData["BrawlersTrophies"][str(playerData["SelectedBrawlers"][0])] += 8
        		calling_instance.player.battlet_oxd = 8
        		calling_instance.player.battlet = 8
        		calling_instance.player.battle_tkns = 50
        	if fields["Unk1"] == 1:
        		if playerData["BrawlPassTokens"] == 34500:
        			playerData["BonusRewardsTokens"] += 0
        		else:
        			playerData["BrawlPassTokens"] += 0
        		playerData["Trophies"] = playerData["Trophies"] - 0
        		playerData["MasteryPoints"][str(playerData["SelectedBrawlers"][0])] += 0
        		playerData["BrawlersTrophies"][str(playerData["SelectedBrawlers"][0])] = playerData["BrawlersTrophies"][str(playerData["SelectedBrawlers"][0])] - 0
        		calling_instance.player.battlet_oxd = 0
        		calling_instance.player.battlet = 0
        		calling_instance.player.battle_tkns = 0
        	if fields["Unk1"] == 2:
        		playerData["Trophies"] += 0
        		if playerData["BrawlPassTokens"] == 34500:
        			playerData["BonusRewardsTokens"] += 25
        		else:
        			playerData["BrawlPassTokens"] += 25
        		playerData["MasteryPoints"][str(playerData["SelectedBrawlers"][0])] += 150
        		playerData["BrawlersTrophies"][str(playerData["SelectedBrawlers"][0])] += 0
        		calling_instance.player.battlet_oxd = 0
        		calling_instance.player.battlet = 0
        		calling_instance.player.battle_tkns = 25
        		
        		#3vs3 rewards end
        else:
        	#3vs3 rewards start
        	if fields["Unk1"] == 0:
        		playerData["Trophies"] += 8
        		if playerData["BrawlPassTokens"] == 34500:
        			playerData["BonusRewardsTokens"] += 50
        		else:
        			playerData["BrawlPassTokens"] += 50
        		playerData["MasteryPoints"][str(playerData["SelectedBrawlers"][0])] += 300
        		playerData["BrawlersTrophies"][str(playerData["SelectedBrawlers"][0])] += 8
        		calling_instance.player.battlet_oxd = 8
        		calling_instance.player.battlet = 8
        		calling_instance.player.battle_tkns = 50
        	if fields["Unk1"] == 1:
        		if playerData["BrawlPassTokens"] == 34500:
        			playerData["BonusRewardsTokens"] += 0
        		else:
        			playerData["BrawlPassTokens"] += 0
        		playerData["Trophies"] = playerData["Trophies"] - 4
        		playerData["MasteryPoints"][str(playerData["SelectedBrawlers"][0])] += 0
        		playerData["BrawlersTrophies"][str(playerData["SelectedBrawlers"][0])] = playerData["BrawlersTrophies"][str(playerData["SelectedBrawlers"][0])] - 4
        		calling_instance.player.battlet_oxd = 0
        		calling_instance.player.battlet = -4
        		calling_instance.player.battle_tkns = 0
        	if fields["Unk1"] == 2:
        		playerData["Trophies"] += 0
        		if playerData["BrawlPassTokens"] == 34500:
        			playerData["BonusRewardsTokens"] += 25
        		else:
        			playerData["BrawlPassTokens"] += 25
        		playerData["MasteryPoints"][str(playerData["SelectedBrawlers"][0])] += 150
        		playerData["BrawlersTrophies"][str(playerData["SelectedBrawlers"][0])] += 0
        		calling_instance.player.battlet_oxd = 0
        		calling_instance.player.battlet = 0
        		calling_instance.player.battle_tkns = 25
        		
        		#3vs3 rewards end
        
        db_instance.updatePlayerData(playerData, calling_instance)
        
        fields["Socket"] = calling_instance.client
        #print(calling_instance.player.battlet_oxd)
        Messaging.sendMessage(23456, fields, cryptoInit, calling_instance.player)
       

    def getMessageType(self):
        return 14110

    def getMessageVersion(self):
        return self.messageVersion
