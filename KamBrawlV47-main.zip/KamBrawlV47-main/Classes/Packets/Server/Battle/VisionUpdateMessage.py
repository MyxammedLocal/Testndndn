from Classes.Packets.PiranhaMessage import PiranhaMessage

class VisionUpdateMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0 #24109

    def encode(self, fields, player):
    	self.writeVInt(160) # Battle Tick
    	self.writeVInt(0) # wifi posral jidko
    	self.writeVInt(0) # Commands Count
    	self.writeVInt(6974) # spectators
    	self.writeBoolean(False) # Live Boolean
        
    def decode(self):
        fields = {}
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24109

    def getMessageVersion(self):
        return self.messageVersion