from Classes.Packets.PiranhaMessage import PiranhaMessage

class StartLoadingMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0 #20559

    def encode(self, fields, player):
#старт лоадинг для 50 версии (zh), made by artmsrd
    	
    	self.writeInt(1) #players count
    	self.writeInt(0)
    	self.writeInt(0)
    	
    	self.writeInt(1) #players array
    	
    	self.writeLong(player.ID[0], player.ID[1])  #player id
    	
    	self.writeVInt(0)
    	self.writeVInt(0)
    	self.writeVInt(540)
    	
    	self.writeInt(30)
    	
    	self.writeBoolean(True) #boolean
    	self.writeDataReference(16, player.SelectedBrawlers[0]) #player brawler id
    	self.writeBoolean(False) #boolean
    	self.writeBoolean(False) #boolean
    	self.writeBoolean(False) #boolean2
    	
    	self.writeBoolean(True)
    	
    	self.writeString(player.Name) #player name
    	
    	self.writeVInt(100)
    	self.writeVInt(28000000) #profile icon
    	self.writeVInt(43000000) #namecolor
    	self.writeVInt(0) #brawl pass color
    	
    	self.writeBoolean(False) #boolean
    	
    	self.writeVInt(0)
    	self.writeVInt(0)
    	self.writeVInt(0)
    	self.writeVInt(0)
#player end    	
    	
    	self.writeInt(0)
    	self.writeInt(0)
    	self.writeInt(0)
    	
    	self.writeVInt(15)
    	self.writeVInt(15)
    	self.writeVInt(15)
    	
    	self.writeBoolean(False)
    	self.writeVInt(15)
    	self.writeVInt(15)
    	self.writeDataReference(15, 15) #map
    	self.writeBoolean(False)
        #start loading end
        
    def decode(self):
        fields = {}
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 20559

    def getMessageVersion(self):
        return self.messageVersion