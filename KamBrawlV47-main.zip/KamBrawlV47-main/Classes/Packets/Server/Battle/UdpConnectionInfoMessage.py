from Classes.Packets.PiranhaMessage import PiranhaMessage

class UdpConnectionInfoMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0 #24112

    def encode(self, fields, player):
        pass
        
    def decode(self):
        fields = {}
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24112

    def getMessageVersion(self):
        return self.messageVersion