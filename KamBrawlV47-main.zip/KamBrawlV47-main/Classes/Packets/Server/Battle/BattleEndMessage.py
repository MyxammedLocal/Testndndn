from Classes.Packets.PiranhaMessage import PiranhaMessage

class BattleEndMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        self.writeLong(0, 0) # Battle UUID High
        self.writeLong(0, 0) # Battle UUID Low
        if fields["MapID"][1] == 32:
            self.writeVInt(2) # Battle End Game Mode (gametype)
        if fields["MapID"][1] == 38:
            self.writeVInt(5) # Battle End Game Mode (gametype)
        else:
            self.writeVInt(1) # Battle End Game Mode (gametype)
        if fields["MapID"][1] == 32 or fields["MapID"][1] == 38:
            self.writeVInt(fields["Rank"]) # Result (Victory/Defeat/Draw/Rank Score)
        else:
        	self.writeVInt(fields["Unk1"]) # Result (Victory/Defeat/Draw/Rank Score)
        self.writeVInt(0) # Tokens Gained (Gained Keys)
        self.writeVInt(player.battlet) # Trophies Result (Metascore change)
        self.writeVInt(0) # Power Play Points Gained (Pro League Points)
        self.writeVInt(0) # Doubled Tokens (Double Keys)
        self.writeVInt(0) # Double Token Event (Double Event Keys)
        self.writeVInt(0) # Token Doubler Remaining (Double Keys Remaining)
        self.writeVInt(0) # game Lenght In Seconds
        self.writeVInt(0) # Epic Win Power Play Points Gained (op Win Points)
        self.writeVInt(0) # Championship Level Reached (CC Wins)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeByte(16) #type
        self.writeVInt(-1) #championchip type
        self.writeBoolean(False)
        
        if fields['MapID'][1] == 32:
            self.writeVInt(0) #players count
        else:
            
            self.writeVInt(1) #players count
            for x in range(1):
                self.writeBoolean(True) #player or bot
                self.writeBoolean(False) #team
                self.writeBoolean(False) #is star player
                self.writeByte(1)
                for i in range(1):
                    self.writeDataReference(16, player.SelectedBrawlers[0])
                self.writeByte(1)
                for i in range(1):
                    self.writeVInt(0)
                self.writeByte(1)
                for i in range(1):
                    self.writeVInt(1250)
                self.writeByte(1)
                for i in range(1):
                    self.writeVInt(11)
                self.writeByte(1)
                for i in range(1):
                    self.writeVInt(0)

                self.writeVInt(0)
                self.writeVInt(0)

                self.writeBoolean(True)
                self.writeLong(player.ID[0], player.ID[1])
                self.writeString(player.Name)
                self.writeVInt(100)
                self.writeVInt(28000000)
                self.writeVInt(43000000 + player.Namecolor)
                	
                self.writeVInt(-1)
                self.writeBoolean(False)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeDataReference(28, 0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)

    def decode(self):
        fields = {}
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 23456

    def getMessageVersion(self):
        return self.messageVersion