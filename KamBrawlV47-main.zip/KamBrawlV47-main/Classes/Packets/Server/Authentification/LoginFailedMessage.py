from Classes.Packets.PiranhaMessage import PiranhaMessage


class LoginFailedMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        self.writeInt(1)
        self.writeString()
        self.writeString()
        self.writeString("")
        self.writeString()
        self.writeString("lox")
        self.writeInt(0)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(0)
        self.writeString()
        self.writeInt(0)
        self.writeBoolean(True)
        self.writeBoolean(True)
        self.writeString()
        self.writeVInt(0)
        self.writeString()
        self.writeBoolean(False)

    def decode(self):
        fields = {}
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 20103

    def getMessageVersion(self):
        return self.messageVersion