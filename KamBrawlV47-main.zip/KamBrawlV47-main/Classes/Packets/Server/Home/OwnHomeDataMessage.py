import time
import random

#import Settings
from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Files.Classes.Cards import Cards


class OwnHomeDataMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):

        self.writeVInt(int(time.time()))
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(player.Trophies) # Trophies
        self.writeVInt(player.Trophies) # Highest Trophies
        self.writeVInt(player.Trophies)
        self.writeVInt(1000)
        self.writeVInt(999999) # Experience
        self.writeDataReference(28, player.Thumbnail) # Thumbnail
        self.writeDataReference(43, player.Namecolor) # Namecolor

        self.writeVInt(26) # Played Game Mode
        for i in range(26):
            self.writeVInt(i)
        
        self.writeVInt(len(player.SelectedSkins))
        for i in player.SelectedSkins:
            self.writeDataReference(29, player.SelectedSkins[i])

        self.writeVInt(0) # Randomizer Skin Selected

        self.writeVInt(0) # Current Random Skin

        self.writeVInt(619) # Unlocked Skins 
        for i in range(619): 
            self.writeDataReference(29, i)

        self.writeVInt(0) # Unlocked Skin Purchase Option

        self.writeVInt(0) # New Item State

        self.writeVInt(0)
        self.writeVInt(player.Trophies)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(5184000) # TrophyRoad Timer
        self.writeVInt(0) # PowerPlay Timer
        self.writeVInt(5184000) # Brawl Pass Timer

        self.writeVInt(141)
        self.writeVInt(135)

        self.writeVInt(5)

        self.writeVInt(93)
        self.writeVInt(206)
        self.writeVInt(456)
        self.writeVInt(792)
        self.writeVInt(729)

        self.writeBoolean(False) # Offer 1
        self.writeBoolean(False) # Offer 2
        self.writeBoolean(True) # Token Doubler Enabled
        self.writeVInt(2)  # Token Doubler New Tag State
        self.writeVInt(2)  # Event Tickets New Tag State
        self.writeVInt(2)  # Coin Packs New Tag State
        self.writeVInt(0)  # Change Name Cost
        self.writeVInt(0)  # Timer For the Next Name Change

 
        '''
        0: Free Box
        1: Coins
        2: Random Brawler
        3: Brawler
        4: Skin
        6: Brawl Box
        8: Power Points 
        9: Token Doubler
        10: Mega Box
        12: Power Points
        14: Big Box
        15: AdBox (Not working anymore)
        16: Gems
        17: Star Points
        19: Pin
        20: Set of Pins
        21: Pin Pack
        23: Pin of Rarity
        25: Player Profile Icon
        27: Pin Pack of Rarity
        30: New Brawer upgraded to level
        31: New Brawer of rarity upgraded to level
        35: Sprays
        37: Omega Box
        38: Credits
        39: Chromocredits
        '''        

       # ShopData = StaticData.ShopData

        self.writeVInt(1) # shop offers count
        
        self.writeVInt(1)  # RewardCount
        for i in range(1):
            self.writeVInt(39) # ItemType
            self.writeVInt(6000)
            self.writeDataReference(0) # CsvID
            self.writeVInt(0)
            

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(950400)
        self.writeVInt(2)
        self.writeVInt(0)
        if 4 in player.BuyedOffers:
        	
            self.writeBoolean(True)
        else:
        	self.writeBoolean(False)
        self.writeVInt(3917)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(49)
        self.writeInt(0)
        self.writeString("GIFT FOR RELEASE!")
        self.writeBoolean(False)
        self.writeString("offer_action")
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeDataReference(0)
        self.writeDataReference(0)
        self.writeBoolean(False)
        self.writeBoolean(True)
        self.writeVInt(0)
            
        self.writeVInt(200)
        self.writeVInt(-1)

        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(1) # Selected Skin
        self.writeDataReference(16, player.SelectedBrawlers[0])

        self.writeString(player.Region) # Location
        self.writeString(player.ContentCreator) # Content Creator

        self.writeVInt(3)
        
        self.writeInt(18)
        self.writeInt(1)
        
        self.writeInt(4)
        self.writeInt(player.battlet_oxd)
        
        self.writeInt(3)
        self.writeInt(player.battle_tkns)
			
        self.writeVInt(0)

        self.writeVInt(2)  # Brawl Pass
        for i in [14, 15]:
            self.writeVInt(i)
            self.writeVInt(player.BrawlPassTokens + player.BonusRewardsTokens)
            self.writeBoolean(False)
            self.writeVInt(0)

            self.writeByte(2)
            self.writeInt(4294967292)
            self.writeInt(4294967295)
            self.writeInt(511)
            self.writeInt(0)

            self.writeByte(1)
            self.writeInt(player.ClaimedRewards1)
            self.writeInt(player.ClaimedRewards2)
            self.writeInt(player.ClaimedRewards3)
            self.writeInt(0)

        self.writeVInt(0)

        self.writeBoolean(True) # Quests
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0) 
          
        self.writeBoolean(True)
        self.writeVInt(976 + 187 + 120)  # Vanity Count
        for i in range(976):
            self.writeDataReference(52, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)
                
        for i in range(187):
            self.writeDataReference(28, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)         
                
        for i in range(120):
            self.writeDataReference(68, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)

        self.writeBoolean(False) # Power League Season Data
        self.writeInt(164) # Logic Daily Data End
        self.writeVInt(-15789) # Logic Conf Data Begin

        self.writeVInt(26) # Count

        # Event Slots IDs Array Start #
        self.writeVInt(1) # Gem Grab
        self.writeVInt(2) # Showdown
        self.writeVInt(3) # Daily Events
        self.writeVInt(4) # Team Events
        self.writeVInt(5) # Duo Showndown
        self.writeVInt(6) # Team Events 2
        self.writeVInt(7) # Special Events(Big Game and other…)
        self.writeVInt(8) # Solo Events (As well as Seasonal Events)
        self.writeVInt(9) # Power Play (Not working)
        self.writeVInt(10) # Seasonal Events
        self.writeVInt(11) # Seasonal Events 2
        self.writeVInt(12) # Candidates of The Day
        self.writeVInt(13) # Winner of The Day
        self.writeVInt(14) # Solo Mode Power League
        self.writeVInt(15) # Team Mode Power League
        self.writeVInt(16) # Club League(Default Map)
        self.writeVInt(17) # Club League(Power Match)
        self.writeVInt(18) # Mystery Mode
        self.writeVInt(20) # Championship Challenge (Stage 1)
        self.writeVInt(21) # Championship Challenge (Stage 2)
        self.writeVInt(22) # Championship Challenge (Stage 3)
        self.writeVInt(23) # Championship Challenge (Stage 4)
        self.writeVInt(24) # Championship Challenge (Stage 5)
        self.writeVInt(30) # Team Events 3?
        self.writeVInt(31) # Team Events 4?
        self.writeVInt(32) # Team Events 5?
        # Event Slots IDs Array End #

        maps = [8, 5]
        self.writeVInt(len(maps)) # Events
        eventIndex = 1
        for i in maps:
            self.writeVInt(-1)
            self.writeVInt(eventIndex)  # Event Type
            self.writeVInt(0)  # Events Begin Countdown
            self.writeVInt(0) # Timer
            self.writeVInt(0) # Tokens
            self.writeDataReference(15, i)  # MapID
            self.writeVInt(-1)  # GameModeVariation
            self.writeVInt(2)  # State
            self.writeString()
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)  # Modifiers     
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(False)  # Map Maker Map Structure Array
            self.writeVInt(0)
            self.writeBoolean(False)  # Power League Data Array
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(False)  # Chronos Text Entry
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(-1)
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(-1)
            eventIndex += 1           

        self.writeVInt(0) # Comming Events

        self.writeVInt(10)  # Brawler Upgrade Cost
        self.writeVInt(20) # 2 Level
        self.writeVInt(35) # 3 Level
        self.writeVInt(75) # 4 Level
        self.writeVInt(140) # 5 Level
        self.writeVInt(290) # 6 Level
        self.writeVInt(480) # 7 Level
        self.writeVInt(800) # 8 Level
        self.writeVInt(1250) # 9 Level
        self.writeVInt(1875) # 10 Level
        self.writeVInt(2800) # 11 Level

        self.writeVInt(4)  # Shop Coins Price
        self.writeVInt(20)
        self.writeVInt(50)
        self.writeVInt(140)
        self.writeVInt(280)

        self.writeVInt(4)  # Shop Coins Count
        self.writeVInt(150) # Count
        self.writeVInt(400) # Count
        self.writeVInt(1200) # Count
        self.writeVInt(2600) # Count
        
        self.writeVInt(2) # Locked For Chronos
        for x in range(1):
            self.writeDataReference(16, 64)
            self.writeInt(0) # Timer
            self.writeInt(0)
            
            self.writeDataReference(16, 63)
            self.writeInt(0) # Timer
            self.writeInt(0)

        self.writeVInt(2)
        self.writeInt(1)
        self.writeInt(41000000 + 54) # Theme ID
        
        self.writeInt(10046)
        self.writeInt(0)
                                     
        self.writeVInt(0) # Timed Int Entry Count
        self.writeVInt(0) # Custom Event

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(6)  # Brawler Cost Gems
        self.writeVInt(0)
        self.writeVInt(29)
        self.writeVInt(79)
        self.writeVInt(169)        
        self.writeVInt(349) 
        self.writeVInt(699) 
        
        self.writeVInt(6)  # Chromatic Brawler Cost Chromacredits
        self.writeVInt(0)
        self.writeVInt(160)
        self.writeVInt(450)
        self.writeVInt(500)        
        self.writeVInt(1500) 
        self.writeVInt(4500)              

        self.writeLong(0, player.ID[1])  # PlayerID

        self.writeVInt(0) # Notification Factory

        self.writeVInt(-64)
        self.writeBoolean(False)
        self.writeVInt(0) # Gatcha Drop
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeBoolean(False)

        self.writeVInt(0) # New Function V46
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        if player.IsStarrRoadCompleted == 0:
            self.writeVInt(1)
        
            rare = [1, 2, 3, 6, 8, 10, 13, 24]
            super_rare = [7, 9, 18, 19, 22, 25, 27, 34, 61, 4]
            epic = [14, 15, 16, 20, 26, 29, 30, 36, 43, 45, 48, 50, 58, 69]
            mythic = [11, 17, 21, 35, 31, 32, 37, 42, 47, 64, 67, 71]
            legendary = [5, 12, 23, 28, 40, 52, 63]
        
            x = player.UnlockingBrawler
        
            self.writeDataReference(16, player.UnlockingBrawler) #brawler
            #credit cost start
            if x in rare:
                self.writeVInt(160)
            elif x in super_rare:
                self.writeVInt(430)
            elif x in epic:
                self.writeVInt(925)
            elif x in mythic:
               self.writeVInt(1900)
            elif x in legendary:
                self.writeVInt(3800)
            else:
                self.writeVInt(1)
            #credit cost end
            	
            #gems cost start
            if x in rare:
                self.writeVInt(29)
            elif x in super_rare:
                self.writeVInt(79)
            elif x in epic:
                self.writeVInt(169)
            elif x in mythic:
                self.writeVInt(359)
            elif x in legendary:
                self.writeVInt(699)
            else:
                self.writeVInt(1)
            #gems cost end
            self.writeVInt(0)
            self.writeVInt(player.CurrCredits) #curr credits
            self.writeVInt(0) #mesto
            self.writeVInt(0)
        else:
        	self.writeVInt(0)
        
        
        self.writeVInt(len(player.brawlers))
        for x in player.brawlers:
            self.writeDataReference(16, x) #brawler
            
            #credit cost start
            if x in rare:
                self.writeVInt(160)
            elif x in super_rare:
                self.writeVInt(430)
            elif x in epic:
                self.writeVInt(925)
            elif x in mythic:
                self.writeVInt(1900)
            elif x in legendary:
                self.writeVInt(3800)
            else:
            	self.writeVInt(1)
            #credit cost end
            	
            #gems cost start
            if x in rare:
                self.writeVInt(29)
            elif x in super_rare:
                self.writeVInt(79)
            elif x in epic:
                self.writeVInt(169)
            elif x in mythic:
                self.writeVInt(359)
            elif x in legendary:
                self.writeVInt(699)
            else:
            	self.writeVInt(1)
            #gems cost end
            self.writeVInt(0)
            self.writeVInt(0) #curr credits
            self.writeVInt(player.brawlers.index(x)) #mesto
            self.writeVInt(0)
        
        self.writeVInt(0)
        
        self.writeVInt(0) #brawler animation
        #starr road end
        
        self.writeVLong(0, player.ID[1])
        self.writeVLong(0, player.ID[1])
        self.writeVLong(0, player.ID[1])
        
        self.writeString(player.Name)
        self.writeBoolean(player.Registered)

        self.writeInt(0)

        self.writeVInt(15)  # Commodity Array Count

        self.writeVInt(7 + len(player.CardsID))

        for x in player.CardsID:
            self.writeDataReference(23, x)
            self.writeVInt(-1)
            self.writeVInt(1)
                                                    
        self.writeDataReference(5, 8)
        self.writeVInt(-1)
        self.writeVInt(player.Coins) # Coins
    
        self.writeDataReference(5, 10)
        self.writeVInt(-1)
        self.writeVInt(0) # Star Points
                               
        self.writeDataReference(5, 13)
        self.writeVInt(-1)        
        self.writeVInt(0) # Club Coins
        
        self.writeDataReference(5, 18)
        self.writeVInt(-1)
        self.writeVInt(5) # Unlocked Sprays Slots  
        
        self.writeDataReference(5, 21)
        self.writeVInt(-1)
        self.writeVInt(player.FamePoints) # Fame
        
        self.writeDataReference(5, 20)
        self.writeVInt(-1)
        self.writeVInt(player.cc) # Chroma Credits        
        
        self.writeDataReference(5, 22)
        self.writeVInt(-1)
        self.writeVInt(player.PowerPoints) # Power Points                    
               
               
        self.writeVInt(len(player.BrawlersTrophies))
        for x in player.BrawlersTrophies:
            self.writeDataReference(16, int(x))
            self.writeVInt(-1)
            self.writeVInt(player.BrawlersTrophies[f"{int(x)}"])
        
        self.writeVInt(len(player.BrawlersTrophies))
        for x in player.BrawlersTrophies:
            self.writeDataReference(16, int(x))
            self.writeVInt(-1)
            self.writeVInt(player.BrawlersTrophies[f"{int(x)}"])

        self.writeVInt(0) # Array

        self.writeVInt(66) # HeroPower
        for x in range(66):
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(1)
        
        self.writeVInt(66) # HeroLevel
        for x in range(66):
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(10)

        self.writeVInt(len(player.Starpowers)) # hero star power and gadget
        for z in player.Starpowers:
        	self.writeDataReference(23, z)
        	self.writeVInt(-1)
        	self.writeVInt(1)

        self.writeVInt(66) # HeroSeenState
        for x in range(66):
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(2)

        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array

        self.writeVInt(player.Gems) # Diamonds
        self.writeVInt(player.Gems) # Free Diamonds
        self.writeVInt(999) # Player Level
        self.writeVInt(100)
        self.writeVInt(0) # CumulativePurchasedDiamonds or Avatar User Level Tier | 10000 < Level Tier = 3 | 1000 < Level Tier = 2 | 0 < Level Tier = 1
        self.writeVInt(0) # Battle Count
        self.writeVInt(0) # WinCount
        self.writeVInt(0) # LoseCount
        self.writeVInt(0) # WinLooseStreak
        self.writeVInt(0) # NpcWinCount
        self.writeVInt(0) # NpcLoseCount
        self.writeVInt(2) # TutorialState | shouldGoToFirstTutorialBattle = State == 0
        self.writeVInt(12)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)

        

    def decode(self):
        fields = {}
        # fields["AccountID"] = self.readLong()
        # fields["HomeID"] = self.readLong()
        # fields["PassToken"] = self.readString()
        # fields["FacebookID"] = self.readString()
        # fields["GamecenterID"] = self.readString()
        # fields["ServerMajorVersion"] = self.readInt()
        # fields["ContentVersion"] = self.readInt()
        # fields["ServerBuild"] = self.readInt()
        # fields["ServerEnvironment"] = self.readString()
        # fields["SessionCount"] = self.readInt()
        # fields["PlayTimeSeconds"] = self.readInt()
        # fields["DaysSinceStartedPlaying"] = self.readInt()
        # fields["FacebookAppID"] = self.readString()
        # fields["ServerTime"] = self.readString()
        # fields["AccountCreatedDate"] = self.readString()
        # fields["StartupCooldownSeconds"] = self.readInt()
        # fields["GoogleServiceID"] = self.readString()
        # fields["LoginCountry"] = self.readString()
        # fields["KunlunID"] = self.readString()
        # fields["Tier"] = self.readInt()
        # fields["TencentID"] = self.readString()
        #
        # ContentUrlCount = self.readInt()
        # fields["GameAssetsUrls"] = []
        # for i in range(ContentUrlCount):
        #     fields["GameAssetsUrls"].append(self.readString())
        #
        # EventUrlCount = self.readInt()
        # fields["EventAssetsUrls"] = []
        # for i in range(EventUrlCount):
        #     fields["EventAssetsUrls"].append(self.readString())
        #
        # fields["SecondsUntilAccountDeletion"] = self.readVInt()
        # fields["SupercellIDToken"] = self.readCompressedString()
        # fields["IsSupercellIDLogoutAllDevicesAllowed"] = self.readBoolean()
        # fields["isSupercellIDEligible"] = self.readBoolean()
        # fields["LineID"] = self.readString()
        # fields["SessionID"] = self.readString()
        # fields["KakaoID"] = self.readString()
        # fields["UpdateURL"] = self.readString()
        # fields["YoozooPayNotifyUrl"] = self.readString()
        # fields["UnbotifyEnabled"] = self.readBoolean()
        # super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24101

    def getMessageVersion(self):
        return self.messageVersion