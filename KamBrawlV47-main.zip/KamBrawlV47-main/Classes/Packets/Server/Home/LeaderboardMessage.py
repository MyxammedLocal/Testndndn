from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler


class LeaderboardMessage(PiranhaMessage):
    
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        db = DatabaseHandler()
        players = db.sortedplayers("Trophies")
        playerscount = len(db.getAll())
        
        if fields["Type"] == 1:
            self.writeVInt(1) # Leaderboard Variation
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeString()

            self.writeVInt(playerscount) # Players Count
            for zv in players:
                self.writeVInt(0)
                self.writeVInt(zv["ID"][1])
                
                self.writeVInt(1)
                self.writeVInt(zv["Trophies"]) #trophies
                
                self.writeVInt(1)
                self.writeString("t.me/kamservers") # Club Name
                
                self.writeString(zv["Name"]) # Player Name
                self.writeVInt(0)
                self.writeVInt(28000000 + zv["Thumbnail"]) # Player Thumbnail
                self.writeVInt(43000000 + zv["Namecolor"]) # Player Name Color
                self.writeVInt(0) # Color Gradients
                self.writeVInt(0) #UNK


            self.writeVInt(0)
            self.writeVInt(1)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeString("RU")
            
        if fields["Type"] == 0:
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeDataReference(16, 0)
        	self.writeString()
        	self.writeVInt(1)
        	
        	for x in range(1):
        	       self.writeVInt(0)
        	       self.writeVInt(1337)
        	       self.writeVInt(1)
        	       self.writeVInt(1337) # Player Trophies
        	       self.writeVInt(1)
        	       self.writeString("тут пока что ничего нет")
        	       self.writeString("t.me/kamservers")# Player Name
        	       self.writeVInt(9) # Player Level
        	       self.writeVInt(28000000 + 73)
        	       self.writeVInt(43000000 + 9)
        	       self.writeVInt(0)
        	       self.writeVInt(0) # Unknown
        	       
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeVInt(0) # Leaderboard global TID
        	self.writeString("RU") #22
        
    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24403

    def getMessageVersion(self):
        return self.messageVersion