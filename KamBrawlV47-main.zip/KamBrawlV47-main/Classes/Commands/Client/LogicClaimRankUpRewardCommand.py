from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import json

class LogicClaimRankUpRewardCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        #calling_instance.readVInt()
        fields["road_id"] = calling_instance.readVInt()
        fields["isbrawler"] = calling_instance.readVInt()
        if fields["isbrawler"] == 0:
            fields["bp_season"] = calling_instance.readVInt()
            fields["reward_index"] = calling_instance.readVInt()
        else:
        	fields["brawler"] = calling_instance.readVInt()
        	fields["bp_season"] = calling_instance.readVInt()
        	fields["reward_index"] = calling_instance.readVInt()
        	
        	
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        print(fields["road_id"])
        print(fields["isbrawler"])
        print(fields["bp_season"])
        print(fields["reward_index"])
        
        fields["IsBrawlPassReward"] = True
        fields["Level"] = fields["reward_index"] + 2
        
        if fields["reward_index"] < 30:
            player_data["ClaimedRewards1"] += (2**(fields["reward_index"]+2))
            
        elif fields["reward_index"] >= 30 and fields["reward_index"] < 61:
            player_data["ClaimedRewards2"] += (2**(fields["reward_index"] - 30))
            
        else:
        	Messaging.sendMessage(24104, fields, cryptoInit)
        
        print(player_data["ClaimedRewards1"], player_data["ClaimedRewards2"])
        
        credits = [0, 4, 8, 12, 16, 20, 25, 30, 33, 38, 43, 49, 54, 58]
        coems = [3, 6, 9, 13, 18, 24, 28, 32, 37, 41, 45, 48, 51, 56, 60]
        coems2000 = []
        chromacredits60 = [7]
        chromacredits40 = [11, 17, 21, 27, 31, 35, 40, 46, 55, 59]
        gems10 = [2, 14, 36, 44, 52]
        gems20 = [22]
        PowerPointsDef = [1, 5, 10, 15, 19, 23, 26, 29, 34, 39, 42, 47, 50, 53, 57]
        powerPoints240 = []
        
        if fields["road_id"] == 10 and fields["reward_index"] in credits:
            
            if player_data["IsStarrRoadCompleted"] == 0:
            	player_data["CurrCredits"] += 85
            else:
            	player_data["FamePoints"] += 85
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 85, 'DataRef': [0, 0],  'RewardID': 22}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["road_id"] == 10 and fields["reward_index"] in coems:
            
            player_data["Coins"] += 640
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 640, 'DataRef': [0, 0],  'RewardID': 7}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["road_id"] == 10 and fields["reward_index"] in coems2000:
            
            player_data["Coins"] += 2000
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 2000, 'DataRef': [0, 0],  'RewardID': 7}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["road_id"] == 10 and fields["reward_index"] in chromacredits60:
            
            player_data["cc"] += 60
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 60, 'DataRef': [0, 0],  'RewardID': 23}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["road_id"] == 10 and fields["reward_index"] in chromacredits40:
            
            player_data["cc"] += 40
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 40, 'DataRef': [0, 0],  'RewardID': 23}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["road_id"] == 10 and fields["reward_index"] in gems10:
            
            player_data["Gems"] += 10
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 10, 'DataRef': [0, 0],  'RewardID': 8}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["road_id"] == 10 and fields["reward_index"] in gems20:
            
            player_data["Gems"] += 20
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 20, 'DataRef': [0, 0],  'RewardID': 8}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["road_id"] == 10 and fields["reward_index"] in PowerPointsDef:
            
            player_data["PowerPoints"] += 165
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 165, 'DataRef': [0, 0],  'RewardID': 24}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
        

    def getCommandType(self):
        return 517