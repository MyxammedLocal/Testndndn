import json
from subprocess import call

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.Files.Classes.Skins import Skins

class LogicSelectSkinCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        fields["SelectedSkin"] = calling_instance.readVInt()
        #calling_instance.readVInt()
        #calling_instance.readVInt()
        #calling_instance.readVInt()
        #calling_instance.readVInt()
        #calling_instance.readVInt()
        #calling_instance.readVInt()
        #calling_instance.readVInt()
        #fields["SelectedBrawler"] = calling_instance.readVInt()
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        fields["SelectedBrawler"] = Skins().getBrawlerBySkin(fields["SelectedSkin"])
        
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        print(calling_instance.player.ID)
        player_data["SelectedBrawlers"][0] = fields["SelectedBrawler"]
        player_data["SelectedSkins"][str(fields["SelectedBrawler"])] = fields["SelectedSkin"]
        db_instance.updatePlayerData(player_data, calling_instance)

    def getCommandType(self):
        return 506