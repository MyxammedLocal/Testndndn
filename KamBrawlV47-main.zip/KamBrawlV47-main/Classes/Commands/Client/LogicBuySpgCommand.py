from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import json
from Classes.Files.Classes.Cards import Cards

class LogicBuySpgCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        fields["id"] = calling_instance.readVInt()
        print("вы купили: ", fields["id"])
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        
        starpowers_list = Cards.getStarpowersID()
        print(starpowers_list)
        
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        if fields["id"] in starpowers_list:
            calling_instance.player.Starpowers.append(fields["id"])
            player_data["Starpowers"].append(fields["id"])
            if player_data["Coins"] >= 2000:
            	calling_instance.player.Coins = calling_instance.player.Coins - 2000
            	player_data["Coins"] = player_data["Coins"] - 2000
            	print("успешно куплено.")
            else:
            	fields["msg"] = "невозможно купить звездную силу, если у тебя меньше 2000 монет!"
            	Messaging.sendMessage(24104, fields, cryptoInit) #если монет меньше чем 2000, то пишет ошибку
            	calling_instance.player.Starpowers.remove(fields["id"])
            	player_data["Starpowers"].remove(fields["id"])
            	print("не хватает монеток для покупки!")
        else:
        	fields["msg"] = "невозможно купить гаджеты, ибо они вызывают вылет в бою"
        	Messaging.sendMessage(24104, fields, cryptoInit) #если пытаются купить гаджет, то тоже пишет ошибку
        	print("невозможно купить гаджет ибо там вылет да")
        
        db_instance.updatePlayerData(player_data, calling_instance)

    def getCommandType(self):
        return 557