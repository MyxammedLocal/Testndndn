from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import json

class LogicBuyBrawlerCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        fields["lix"] = calling_instance.readVInt()
        fields["brawler"] = calling_instance.readDataReference()
        calling_instance.readVInt()
        fields["lox"] = calling_instance.readVInt()
        print(fields["lox"])
        #print(fields["lix"])
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        fields["IsBrawlPassReward"] = False
        
        if fields["lox"] == 20:
        	if fields["brawler"][1] == 70:
        		player_data["cc"] = player_data["cc"] - 2500
        	if fields["brawler"][1] == 68:
        		 player_data["cc"] = player_data["cc"] - 1250
        	else:
        		player_data["cc"] = player_data["cc"] - 500
        if fields["lox"] != 20:
        	Messaging.sendMessage(24104, fields, cryptoInit)
        		
        #unlocked_brawler = [0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 95, 100, 105, 110, 115, 120, 125, 130, 177, 182, 188, 194, 200, 206, 218, 224, 230, 236, 279, 296, 303, 320, 327, 334, 341, 358, 365, 372, 379, 386, 393, 410, 417, 427, 434, 448, 466, 474, 491, 499, 507, 515, 523, 531, 539, 547, 557]
        if fields["brawler"][1] == 35:
        	player_data["CardsID"].append(224)#гейл
        if fields["brawler"][1] == 38:
        	player_data["CardsID"].append(279)#вольт
        if fields["brawler"][1] == 39:
        	player_data["CardsID"].append(296)#колет
        if fields["brawler"][1] == 41:
        	player_data["CardsID"].append(320)#лу
        if fields["brawler"][1] == 44:
        	player_data["CardsID"].append(341)#гавс
        if fields["brawler"][1] == 46:
        	player_data["CardsID"].append(365)#бель
        if fields["brawler"][1] == 49:
        	player_data["CardsID"].append(386)#баз
        if fields["brawler"][1] == 51:
        	player_data["CardsID"].append(410)#эш
        if fields["brawler"][1] == 53:
        	player_data["CardsID"].append(427)#лола
        if fields["brawler"][1] == 54:
        	player_data["CardsID"].append(434)#фэнг
        if fields["brawler"][1] == 56:
        	player_data["CardsID"].append(448)#ева
        if fields["brawler"][1] == 57:
        	player_data["CardsID"].append(466)#сранет
        if fields["brawler"][1] == 59:
        	player_data["CardsID"].append(491)#отис
        if fields["brawler"][1] == 60:
        	player_data["CardsID"].append(499)#сэм
        if fields["brawler"][1] == 62:
        	player_data["CardsID"].append(515)#бимбастер
        if fields["brawler"][1] == 65:
        	player_data["CardsID"].append(539)#мэнди
        if fields["brawler"][1] == 66:
        	player_data["CardsID"].append(547)#р-т
        if fields["brawler"][1] == 68:
        	player_data["CardsID"].append(565)#мэйси
        if fields["brawler"][1] == 70:
        	player_data["CardsID"].append(581)#корделиус
        	
        	
        		
        player_data["delivery_items"] = {
            'Boxes': []
        }
        box = {
       'Type': 0,
       'Items': []
        }
        item = {'Amount': 1, 'DataRef': [16, fields["brawler"][1]],  'RewardID': 1}
        box['Type'] = 100
        box['Items'].append(item)
        player_data["delivery_items"]['Boxes'].append(box)
            
        db_instance.updatePlayerData(player_data, calling_instance)
        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 203}
        fields["PlayerID"] = calling_instance.player.ID
        Messaging.sendMessage(24111, fields, cryptoInit)

    def getCommandType(self):
        return 560