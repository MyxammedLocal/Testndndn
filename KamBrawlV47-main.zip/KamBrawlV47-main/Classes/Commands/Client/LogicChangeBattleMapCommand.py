from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler

class LogicChangeBattleMapCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        LogicCommand.encode(self, fields)
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        calling_instance.readVInt()
        fields["CsvID"] = calling_instance.readVInt()
        fields["id"] = calling_instance.readVInt()
        print(fields["id"])
        calling_instance.readVInt()
        if fields["CsvID"] != 0:
            fields["indx"] = calling_instance.readVInt()
        else:
        	fields["indx"] = calling_instance.readBoolean()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        playerData = db_instance.getPlayer(calling_instance.player.ID)
        if fields["CsvID"] == 28 and fields["indx"] == 0:
        	playerData["BattleMapIcon1"] = fields["id"]
        if fields["CsvID"] == 28 and fields["indx"] == 1:
        	playerData["BattleMapIcon2"] = fields["id"]
        if fields["CsvID"] == 52:
        	playerData["BattleMapPin"] = fields["id"]
        if fields["CsvID"] == 76:
        	playerData["BattleMapTitle"] = fields["id"]
        if fields["CsvID"] == 0 and fields["indx"] == 0:
        	playerData["BattleMapIcon1"] = fields["id"]
        #if fields["CsvID"] == 0:
        	#playerData["BattleMapIcon1"] = -1
        db_instance.updatePlayerData(playerData, calling_instance)

    def getCommandType(self):
        return 568